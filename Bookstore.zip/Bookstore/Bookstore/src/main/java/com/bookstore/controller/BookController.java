package com.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.bookstore.entity.Book;
import com.bookstore.entity.MyBookList;
import com.bookstore.service.BookService;
import com.bookstore.service.MyBookListService;

@Controller
public class BookController {
    
    @Autowired
    private BookService service;
    
    @Autowired
    private MyBookListService myBookService;
    
    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @GetMapping("/book_register")
    public String bookRegister() {
        return "bookRegister";
    }
    
    @GetMapping("/available_books")
    public ModelAndView getAllBook() {
        List<Book> list = service.getAllBook();
        return new ModelAndView("bookList", "book", list);
    }
    
    @PostMapping("/save")
    public String addBook(@ModelAttribute Book b) {
        service.save(b);
        return "redirect:/available_books";
    }
    
    @GetMapping("/my_books")
    public String getMyBooks(Model model) {
        List<MyBookList> list = myBookService.getAllMyBooks();
        double totalPrice = list.stream()
        		.mapToDouble(b -> b.getPrice() != null ? Double.parseDouble(b.getPrice()) : 0.0)
                                .sum();
        model.addAttribute("book", list);
        model.addAttribute("totalPrice", totalPrice);  // Add the total price
        return "myBooks";
    }
  
    
    // Show payment choice page
    @GetMapping("/choosePayment")
    public String choosePayment(@RequestParam("totalPrice") double totalPrice, Model model) {
        model.addAttribute("totalPrice", totalPrice);
        return "choosePayment";  // Render the payment choice page
    }

    // Render payment form if online payment is chosen
    @GetMapping("/payment")
    public String paymentPage(@RequestParam("totalPrice") double totalPrice, Model model) {
    	List<MyBookList> myBooks = myBookService.getAllMyBooks();

        // Add the list of books and total price to the model
        model.addAttribute("books", myBooks);
        model.addAttribute("totalPrice", totalPrice);
        
        
        return "payment";  // Payment form for online payments
    }

    
    // Process payment (dummy endpoint for example)
    @PostMapping("/processPayment")
    public String processPayment(@RequestParam("name") String name,
                                 @RequestParam("cardNumber") String cardNumber,
                                 @RequestParam("expiryDate") String expiryDate,
                                 @RequestParam("cvv") String cvv,
                                 @RequestParam("totalPrice") double totalPrice,
                                 Model model) {
        boolean paymentSuccess = true;  // Simulated payment success for example

        if (paymentSuccess) {
            model.addAttribute("message", "Payment successful!");
        } else {
            model.addAttribute("message", "Payment failed. Please try again.");
        }

        return "paymentConfirmation";  // Display payment result
    }

    // Display offline payment confirmation
    @GetMapping("/offlineConfirmation")
    public String offlinePaymentConfirmation(Model model) {
        model.addAttribute("message", "Thank you! Please visit the store to complete the payment.");
        return "paymentConfirmation";  // Show offline payment message
    }


    @RequestMapping("/mylist/{id}")
    public String getMyList(@PathVariable("id") int id) {
        Book b = service.getBookById(id);
        MyBookList mb = new MyBookList(b.getId(), b.getName(), b.getAuthor(), b.getPrice(), b.getGenere(), b.getDescription());
        myBookService.saveMyBooks(mb);
        return "redirect:/my_books";
    }

    @RequestMapping("/editBook/{id}")
    public String editBook(@PathVariable("id") int id, Model model, @RequestParam(value = "username", required = false) String username,
                           @RequestParam(value = "password", required = false) String password) {
        // Check if admin credentials are provided
        if ("revanth".equals(username) && "revanth".equals(password)) {
            Book b = service.getBookById(id);
            model.addAttribute("book", b);
            return "bookEdit";
        }
        return "redirect:/available_books";
    }

    @RequestMapping("/adminDeleteLogin/{id}")
    public String adminDeleteLogin(@PathVariable("id") int id,
                                   @RequestParam(value = "username", required = false) String username,
                                   @RequestParam(value = "password", required = false) String password,
                                   Model model) {
        if ("revanth".equals(username) && "revanth".equals(password)) {
            service.deleteById(id);
            return "redirect:/available_books";
        }
        model.addAttribute("error", "Invalid admin credentials.");
        return "adminDeleteLogin";
    }

    
    @GetMapping("/search")
    public ModelAndView searchBooks(@RequestParam("keyword") String keyword) {
        List<Book> list = service.searchBooks(keyword);
        return new ModelAndView("bookList", "book", list);
    }

    @GetMapping("/adminLogin")
    public String adminLogin(@RequestParam("id") int id, Model model) {
        model.addAttribute("id", id);
        return "adminLogin";
    }
    
    

}
