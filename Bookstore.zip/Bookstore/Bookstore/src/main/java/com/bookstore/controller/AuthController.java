package com.bookstore.controller;

import com.bookstore.entity.User;
import com.bookstore.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/login")
    public String showLoginForm() {
        return "login"; // Points to login.html
    }

    @PostMapping("/login")
    public String handleLogin(@RequestParam String email, @RequestParam String password) {
        User user = userRepository.findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            // Authentication success
            return "redirect:/home"; // Redirect to home page
        } else {
            // Authentication failed
            return "redirect:/login?error"; // Redirect back to login with error
        }
    }

    @GetMapping("/")
    public String showSignupForm() {
        return "signup"; // Points to signup.html
    }

    @PostMapping("/signup")
    public String handleSignup(@RequestParam String username, @RequestParam String email, @RequestParam String password) {
        // Check if the email is already used
        if (userRepository.findByEmail(email) == null) {
            User newUser = new User();
            newUser.setUsername(username);
            newUser.setEmail(email);
            newUser.setPassword(password); // In production, never store passwords as plain text
            userRepository.save(newUser);
            return "redirect:/home"; // Redirect to login page after successful sign-up
        } else {
            return "redirect:/?error"; // Redirect back to signup with error
        }
    }
}
