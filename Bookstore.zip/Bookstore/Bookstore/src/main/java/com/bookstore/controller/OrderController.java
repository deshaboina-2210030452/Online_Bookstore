	package com.bookstore.controller;
	import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestParam;
	import org.springframework.web.servlet.ModelAndView;

	@Controller
	public class OrderController {

	    @PostMapping("/orders/new")
	    public String placeOrder(@RequestParam String bookId, @RequestParam String name, @RequestParam String address, @RequestParam String phone) {
	        // Logic to handle the order (e.g., save to database)
	        // After handling the order, redirect to success page
	        return "redirect:/success"; // This should map to the success page
	    }

	    @GetMapping("/success")
	    public String success() {
	        return "success"; // This should map to success.html
	    }
	}
